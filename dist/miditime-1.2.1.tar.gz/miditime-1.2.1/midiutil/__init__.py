try:
    from midiutil.MidiFile import *
except:
    from src.midiutil.MidiFile import *


__all__ = ['MIDIFile', 'MAJOR', 'MINOR', 'SHARPS', 'FLATS']